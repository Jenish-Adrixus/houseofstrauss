<?php

/**
 * Storefront automatically loads the core CSS even if using a child theme as it is more efficient
 * than @importing it in the child theme style.css file.
 *
 * Uncomment the line below if you'd like to disable the Storefront Core CSS.
 *
 * If you don't plan to dequeue the Storefront Core CSS you can remove the subsequent line and as well
 * as the sf_child_theme_dequeue_style() function declaration.
 */
//add_action( 'wp_enqueue_scripts', 'sf_child_theme_dequeue_style', 999 );

/**
 * Dequeue the Storefront Parent theme core CSS
 */
function sf_child_theme_dequeue_style() {
    wp_dequeue_style( 'storefront-style' );
    wp_dequeue_style( 'storefront-woocommerce-style' );
}

if ( ! function_exists( 'add_script_style' ) ) {
    function add_script_style() {
        /* Register & Enqueue Styles. */
        
        wp_register_style( 'shop-theme-icon', get_stylesheet_directory_uri().'/assets/css/shop-theme-icon.css' );
        wp_enqueue_style( 'shop-theme-icon' );
        wp_register_style( 'bootstrap', get_stylesheet_directory_uri().'/assets/css/bootstrap.min.css' );
        wp_enqueue_style( 'bootstrap' );
        wp_register_style( 'slick-theme', get_stylesheet_directory_uri().'/assets/css/slick-theme.css' );
        wp_enqueue_style( 'slick-theme' );
        wp_register_style( 'slick', get_stylesheet_directory_uri().'/assets/css/slick.css' );
        wp_enqueue_style( 'slick' );
        wp_register_style( 'style', get_stylesheet_directory_uri().'/assets/css/style.css' );
        wp_enqueue_style( 'style' );
        wp_register_style( 'responsive', get_stylesheet_directory_uri().'/assets/css/responsive.css' );
        wp_enqueue_style( 'responsive' );

        /* Register & Enqueue scripts. */

        wp_register_script( 'custom-script', get_stylesheet_directory_uri().'/assets/js/bootstrap.min.js' );
        wp_enqueue_script( 'custom-script');
        wp_register_script( 'custom-script-2', get_stylesheet_directory_uri().'/assets/js/slick.min.js', array('jquery') );
        wp_enqueue_script( 'custom-script-2');
        wp_register_script( 'custom', get_stylesheet_directory_uri().'/assets/js/custom.js', array('jquery'));
        wp_enqueue_script( 'custom');

    }
}
add_action( 'wp_enqueue_scripts', 'add_script_style', 10 );
/**
 * Note: DO NOT! alter or remove the code above this text and only add your custom PHP functions below this text.
 */

/* New Custome Functions Start*/

if( function_exists('acf_add_options_page') ) {
	
	acf_add_options_page(array(
		'page_title' 	=> 'Theme General Settings',
		'menu_title'	=> 'Theme Settings',
		'menu_slug' 	=> 'theme-general-settings',
		'capability'	=> 'edit_posts',
		'redirect'		=> false
	));
}

/* New Custome Functions end*/

/**
 * Show cart contents / total Ajax
 */
add_filter( 'woocommerce_add_to_cart_fragments', 'woocommerce_header_add_to_cart_fragment' );

function woocommerce_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;

	ob_start();

	?>	
	<span class="itemCount carCounts"><?php  echo WC()->cart->get_cart_contents_count(); ?></span>
	<?php
	$fragments['span.carCounts'] = ob_get_clean();
	return $fragments;
} 

// Utility function, to display BACS accounts detail
function get_bacs_account_details_html( $echo = true, $type = 'list' ) {

    ob_start();

    $gateway    = new WC_Gateway_BACS();
    $country    = WC()->countries->get_base_country();
    $locale     = $gateway->get_country_locale();
    $bacs_info  = get_option( 'woocommerce_bacs_accounts');

    // Get sortcode label in the $locale array and use appropriate one
    $sort_code_label = isset( $locale[ $country ]['sortcode']['label'] ) ? $locale[ $country ]['sortcode']['label'] : __( 'Sort code', 'woocommerce' );

    if( $type = 'list' ) :
    ?>
    <div class="woocommerce-bacs-bank-details">
    <h2 class="wc-bacs-bank-details-heading"><?php _e('Our Bank Details'); ?></h2>
    <?php
    $i = -1;
    if ( $bacs_info ) : foreach ( $bacs_info as $account ) :
    $i++;

    $account_name   = esc_attr( wp_unslash( $account['account_name'] ) );
    $bank_name      = esc_attr( wp_unslash( $account['bank_name'] ) );
    $account_number = esc_attr( $account['account_number'] );
    $sort_code      = esc_attr( $account['sort_code'] );
    $iban_code      = esc_attr( $account['iban'] );
    $bic_code       = esc_attr( $account['bic'] );
    ?>
<!--     <h3 class="wc-bacs-bank-details-account-name"><?php //echo $account_name; ?>:</h3> -->
    <ul class="wc-bacs-bank-details order_details bacs_details">
        <li class="bank_name"><?php _e('Name'); ?>: <strong><?php echo $account_name; ?></strong></li>
        <li class="iban"><?php _e('IBAN'); ?>: <strong><?php echo $iban_code; ?></strong></li>
        <li class="bic"><?php _e('BIC'); ?>: <strong><?php echo $bic_code; ?></strong></li>
        <!-- <li class="country"><?php //_e('LAND'); ?>: <strong>Deutschland</strong></li> -->
    </ul>
    <?php endforeach; endif; ?>
    </div>
    <?php
	endif;
    $output = ob_get_clean();
// 	var_dump($output);
    if ( $echo )
// 		echo '123';
        echo $output;
    else
        return $output;
}

// checkout field

//show attributes after summary in product single view
add_action('woocommerce_single_product_summary', function() {
	//template for this is in storefront-child/woocommerce/single-product/product-attributes.php
	global $product;
	echo $product->list_attributes();
}, 25);

//home page add to cart issue start

// function custom_add_to_cart_redirect() {
//     global $wp_query;
//     $queried_data  = $wp_query->get_queried_object();
//     $current_page_url = get_page_link( $queried_data->ID );
//     return $current_page_url;
// }
// add_filter( 'woocommerce_add_to_cart_redirect', 'custom_add_to_cart_redirect' );

//home page add to cart issue end