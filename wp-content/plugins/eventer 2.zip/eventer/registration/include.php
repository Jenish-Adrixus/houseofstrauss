<?php
include_once(EVENTER__PLUGIN_PATH . '/registration/db.php');
include_once(EVENTER__PLUGIN_PATH . '/registration/db_functions.php');
include_once(EVENTER__PLUGIN_PATH . '/registration/RegistrationProcess.php');
include_once(EVENTER__PLUGIN_PATH . '/registration/RegistrationTable.php');
include_once(EVENTER__PLUGIN_PATH . '/registration/Bookings.php');
