<div class="eventer-filter-datewise-wrap" style="display: flex;">
    <div class="eventer-fdww-inner">
        <span><?php esc_html_e('Show events from ', 'eventer'); ?></span>
        <input type="text" class="eventer-filter-datewise" id="eventer_from" name="from" value="">
    </div>
    <div class="eventer-fdww-inner">
        <span>
            <?php esc_html_e('to ', 'eventer'); ?></span>
        <input type="text" class="eventer-filter-datewise" id="eventer_to" name="to" value="">
    </div>
</div>